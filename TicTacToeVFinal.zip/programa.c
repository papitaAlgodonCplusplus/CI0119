#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

void imprimirMatrix(int matrix[16]) {
	printf("%d", matrix[0]);
	printf(" ");
	printf("%d", matrix[1]);
	printf(" ");
	printf("%d", matrix[2]);
	printf(" ");
	printf("%d", matrix[3]);
	printf("\n");
	printf("%d", matrix[4]);
	printf(" ");
	printf("%d", matrix[5]);
	printf(" ");
	printf("%d", matrix[6]);
	printf(" ");
	printf("%d", matrix[7]);
	printf("\n");
	printf("%d", matrix[8]);
	printf(" ");
	printf("%d", matrix[9]);
	printf(" ");
	printf("%d", matrix[10]);
	printf(" ");
	printf("%d", matrix[11]);
	printf("\n");
	printf("%d", matrix[12]);
	printf(" ");
	printf("%d", matrix[13]);
	printf(" ");
	printf("%d", matrix[14]);
	printf(" ");
	printf("%d", matrix[15]);
	printf("\n");
}
void imprimirMatrixE() {
	char matrix[16] = { 'A', 'B','C','D','E','F','G','H','I','J','K','L','M','N','O','P' };
	printf("\n");
	printf("%c", matrix[0]);
	printf(" ");
	printf("%c", matrix[1]);
	printf(" ");
	printf("%c", matrix[2]);
	printf(" ");
	printf("%c", matrix[3]);
	printf("\n");
	printf("%c", matrix[4]);
	printf(" ");
	printf("%c", matrix[5]);
	printf(" ");
	printf("%c", matrix[6]);
	printf(" ");
	printf("%c", matrix[7]);
	printf("\n");
	printf("%c", matrix[8]);
	printf(" ");
	printf("%c", matrix[9]);
	printf(" ");
	printf("%c", matrix[10]);
	printf(" ");
	printf("%c", matrix[11]);
	printf("\n");
	printf("%c", matrix[12]);
	printf(" ");
	printf("%c", matrix[13]);
	printf(" ");
	printf("%c", matrix[14]);
	printf(" ");
	printf("%c", matrix[15]);
	printf("\n");
}
extern void DesBloq(int*); //Desbloquea las casillas centrales al comienzo
extern int EI(int); //Verifica entradas validas
extern void TurnoJ1(int*, int*, char); //Controla las matrices en el turno del jugador 1 segun sea el char
extern void TurnoJ2(int*, int*, char); //Controla las matrices en el turno del jugador 2 segun sea el char
extern int CO(int, int*); //Verifica casillas ocupadas
extern void MConteo(int*, int*); //Actualiza la matriz segun la matriz de conteo (7 turnos)
extern int GanaJ1(int*); //Verifica si gana el jugador 1
extern int GanaJ2(int*); //Verifica si gana el jugador 1
int main(int argc, char* args[])
{
	char respuesta2 = '0';
	while (respuesta2 != 'N') {
	char respuesta;
	bool pasarJ1 = false;
	bool pasarJ2 = false;
	int ganador = 0;
	int flag3s = 1;
	int flagCO = 0;
	int resp = 0;
	int resp2 = 0;
	int flagEI = 0;
	int contadorTurnos = 0;
	int matrix[16] = { 0,0,0,0,0,3,3,0,0,3,3,0,0,0,0 };
	int matrixConteo[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };	
	imprimirMatrix(matrix);
	printf("Bienvenidos, para seleccionar una casilla, usar la letra en mayuscula correspondiente como en el siguiente ejemplo: \n");
	imprimirMatrixE();
		ganador = 0;
		while (ganador == 0) {
			flagCO = 0;
			flagEI = 0;
			pasarJ1 = false;
			pasarJ2 = false;
			if (ganador == 0) {
				while (!pasarJ2) {
					printf("Seleccione una casilla, jugador 1 (o digite 5 para ver el ejemplo de entradas) \n");
					scanf(" %c", &respuesta);
					int ia = respuesta;
					//scanf not assembly related problem 
					if (ia >= 48 && ia <= 57) {
						flagEI = 1;
					}
					ia = ia - 65;
					//assembly bug
					resp = matrix[ia+1];
					resp2 = matrixConteo[ia + 1];
					if (ia >= 0) {
						flagEI = EI(ia);
						flagCO = CO(ia, matrix);
					}
					if (flagEI == 1 && respuesta != '5') {
						printf("Entrada Invalida \n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (flagCO == 1) {
						printf("Casilla Ocupada\n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (respuesta == '5') {
						imprimirMatrixE();
						flagCO = 0;
						flagEI = 0;
					}
					else {
						TurnoJ1(matrix, matrixConteo, respuesta);
						matrix[ia + 1] = resp;
						matrixConteo[ia + 1] = resp2;
						pasarJ2 = true;
						flagCO = 0;
						flagEI = 0;
					}
				}
				ganador = GanaJ1(matrix);
				DesBloq(matrix);
				MConteo(matrix, matrixConteo);
				imprimirMatrix(matrix);
			}
			if (ganador == 0) {
				while (!pasarJ1) {
					printf("Seleccione una casilla, jugador 2 (o digite 5 para ver el ejemplo de entradas) \n");
					scanf(" %c", &respuesta);
					int ia = respuesta;
					//scanf not assembly related problem 
					if (ia >= 48 && ia <= 57) {
						flagEI = 1;
					}
					ia = ia - 65;
					//assembly bug
					resp = matrix[ia + 1];
					resp2 = matrixConteo[ia + 1];
					if (ia >= 0) {
						flagEI = EI(ia);
						flagCO = CO(ia, matrix);
					}
					if (flagEI == 1 && respuesta != '5') {
						printf("Entrada Invalida \n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (flagCO == 1) {
						printf("Casilla Ocupada\n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (respuesta == '5') {
						imprimirMatrixE();
						flagCO = 0;
						flagEI = 0;
					}
					else {
						TurnoJ2(matrix, matrixConteo, respuesta);
						matrix[ia + 1] = resp;
						matrixConteo[ia + 1] = resp2;
						pasarJ1 = true;
						flagCO = 0;
						flagEI = 0;
					}
				}
				ganador = GanaJ2(matrix);
				MConteo(matrix, matrixConteo);
				imprimirMatrix(matrix);
			}
		}
		printf("Gana jugador ");
		printf("%d", ganador);
		printf("\n");
		printf("Desea continuar? (N para no, otro digito para si)\n");
		scanf(" %c", &respuesta2);
	}
    return 0;
}