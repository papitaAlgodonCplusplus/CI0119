#include <stdbool.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

void imprimirMatrix(int matriz[16]) {
	char matrix[16] = { 'A', 'B','C','D','E','F','G','H','I','J','K','L','M','N','O','P' };
	printf("                                                            ");
	printf("   |   |   |   \n");
	for (int i = 0; i < 15; i++)
	{
		if (matriz[i] != 0  && matriz[i] != 3) {
			matrix[i] = matriz[i] + 48;
		}
		if (matriz[i] == 1) {
			matrix[i] = 'X';
		}
		if (matriz[15] == 1) {
			matrix[15] = 'X';
		}
		if (matriz[15] == 2) {
			matrix[15] = '0';
		}
		if (matriz[i] == 2) {
			matrix[i] = '0';
		}
	}
	printf("                                                             %c ", matrix[0]);
	printf("|");
	printf(" %c ", matrix[1]); 
	printf("|");
	printf(" %c ", matrix[2]);
	printf("|");
	printf(" %c ", matrix[3]);
	
	printf("\n                                                            ___|___|___|___\n");
	printf("                                                               |   |   |   \n");
	printf("                                                             %c ", matrix[4]);
	printf("|");
	printf(" %c ", matrix[5]);
	printf("|");
	printf(" %c ", matrix[6]);
	printf("|");
	printf(" %c ", matrix[7]);
	printf("\n                                                            ___|___|___|___\n");
	printf("                                                               |   |   |   \n");
	printf("                                                             %c ", matrix[8]);
	printf("|");
	printf(" %c ", matrix[9]);
	printf("|");
	printf(" %c ", matrix[10]);
	printf("|");
	printf(" %c ", matrix[11]);
	printf("\n                                                            ___|___|___|___\n");
	printf("                                                               |   |   |   \n");
	printf("                                                             %c ", matrix[12]);
	printf("|");
	printf(" %c ", matrix[13]);
	printf("|");
	printf(" %c ", matrix[14]);
	printf("|");
	printf(" %c ", matrix[15]);
	printf("\n                                                               |   |   |   ");
	printf("\n ");				
	printf("\n");

}
void imprimirMatrixE() {
	printf("\n\n Bienvenido al juego, las reglas son simples. \n - Por turnos, cada jugador selecciona la letra correspondiente a la casilla donde desea poner su jugada. \n - Una X o 0 aparecera en la casilla correspondiente al jugador1(X) o jugador2(0) \n - Se gana el juego cuando alguno de los jugadores logre jugar 3 casillas horizontales, verticales o diagoles  \n - CUIDADO!Cada 5 turnos se elimina la jugada mas antigua dejando la casilla utilizable  \n - No se pueden jugar las casillas centrales en el primer turno ni se puede jugar una casilla que ya este ocupada  \n - BUENA SUERTE!\n\n");
}
extern void DesBloq(int*); //Desbloquea las casillas centrales al comienzo
extern int EI(int); //Verifica entradas validas
extern void TurnoJ1(int*, int*, char); //Controla las matrices en el turno del jugador 1 segun sea el char
extern void TurnoJ2(int*, int*, char); //Controla las matrices en el turno del jugador 2 segun sea el char
extern int CO(int, int*); //Verifica casillas ocupadas
extern void MConteo(int*, int*); //Actualiza la matriz segun la matriz de conteo (7 turnos)
extern int GanaJ1(int*); //Verifica si gana el jugador 1
extern int GanaJ2(int*); //Verifica si gana el jugador 1
int main(int argc, char* args[])
{
	srand(time(0));
	char respuesta2 = '0';
	while (respuesta2 != 'N') {
	bool pasarJ1 = false;
	bool pasarJ2 = false;
	int ganador = 0;
	int flag3s = 1;
	int flagCO = 0;
	int resp = 0;
	int resp2 = 0;
	int flagEI = 0;
	int contadorTurnos = 0;
	int matrix[16] = { 0,0,0,0,0,3,3,0,0,3,3,0,0,0,0 };
	int matrixConteo[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0 };
	char respuesta;
	system("clear");
	printf("Bienvenido/s, desea/n jugar contra un bot? (Digite 'S' para si, otra tecla para no)\n");
	scanf(" %c", &respuesta);
	if (respuesta == 'S') {
		int something = 0;
		system("clear");
		printf("Bienvenido, para seleccionar una casilla, usar la letra en mayuscula correspondiente como en el siguiente ejemplo: \n");
		imprimirMatrix(matrix);
		imprimirMatrixE();
		ganador = 0;
		while (ganador == 0) {
			flagCO = 0;
			flagEI = 0;
			pasarJ1 = false;
			pasarJ2 = false;
			if (ganador == 0) {
				while (!pasarJ2) {
					printf("Jugador 1: Digite la letra correspondiente a su casilla (o digite 5 para ver la ayuda) \n");
					scanf(" %c", &respuesta);
					int ia = respuesta;
					//scanf not assembly related problem 
					if (ia >= 48 && ia <= 57) {
						flagEI = 1;
					}
					ia = ia - 65;
					//assembly bug
					resp = matrix[ia + 1];
					resp2 = matrixConteo[ia + 1];
					if (ia >= 0) {
						flagEI = EI(ia);
						flagCO = CO(ia, matrix);
					}
					if (flagEI == 1 && respuesta != '5') {
						printf("Entrada Invalida \n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (flagCO == 1) {
						printf("Casilla Ocupada\n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (respuesta == '5') {
						imprimirMatrixE();
						flagCO = 0;
						flagEI = 0;
					}
					else {
						TurnoJ1(matrix, matrixConteo, respuesta);
						matrix[ia + 1] = resp;
						matrixConteo[ia + 1] = resp2;
						pasarJ2 = true;
						flagCO = 0;
						flagEI = 0;
					}
				}
				ganador = GanaJ1(matrix);
				DesBloq(matrix);
				MConteo(matrix, matrixConteo);
				system("clear");
				imprimirMatrix(matrix);
			}
			if (ganador == 0) {
				while (!pasarJ1) {
					int ia = 0;
					respuesta = '0';
					while (respuesta == '0') {
						int random = rand() % 16;
						if (matrix[random] != 0) {}
						else {
							ia = random;
							respuesta = '1';
						}
					}
					//assembly bug
					char matrixaux[16] = { 'A', 'B','C','D','E','F','G','H','I','J','K','L','M','N','O','P' };
					resp = matrix[ia + 1];
					resp2 = matrixConteo[ia + 1];
					something = ia;
					TurnoJ2(matrix, matrixConteo, matrixaux[ia]);
					matrix[ia + 1] = resp;
					matrixConteo[ia + 1] = resp2;
					pasarJ1 = true;
					flagCO = 0;
					flagEI = 0;
				}
				ganador = GanaJ2(matrix);
				MConteo(matrix, matrixConteo);
				char matrixaux[16] = { 'A', 'B','C','D','E','F','G','H','I','J','K','L','M','N','O','P' };
				system("clear");
				printf("El bot a seleccionado la casilla correspondiente a la letra: %c", matrixaux[something]);
				printf("\n");
				printf("\n");
				imprimirMatrix(matrix);
			}
		}
		printf("Gana jugador ");
		printf("%d", ganador);
		printf("\n");
		printf("Desea continuar? (N para no, otro digito para si)\n");
		scanf(" %c", &respuesta2);
	}
	else {
		system("clear");
		printf("Bienvenidos, para seleccionar una casilla, usar la letra en mayuscula correspondiente como en el siguiente ejemplo: \n");
		imprimirMatrix(matrix);
		imprimirMatrixE();
		ganador = 0;
		while (ganador == 0) {
			flagCO = 0;
			flagEI = 0;
			pasarJ1 = false;
			pasarJ2 = false;
			if (ganador == 0) {
				while (!pasarJ2) {
					printf("Jugador 1: Digite la letra correspondiente a su casilla (o digite 5 para ver la ayuda) \n");
					scanf(" %c", &respuesta);
					int ia = respuesta;
					//scanf not assembly related problem 
					if (ia >= 48 && ia <= 57) {
						flagEI = 1;
					}
					ia = ia - 65;
					//assembly bug
					resp = matrix[ia + 1];
					resp2 = matrixConteo[ia + 1];
					if (ia >= 0) {
						flagEI = EI(ia);
						flagCO = CO(ia, matrix);
					}
					if (flagEI == 1 && respuesta != '5') {
						printf("Entrada Invalida \n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (flagCO == 1) {
						printf("Casilla Ocupada\n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (respuesta == '5') {
						imprimirMatrixE();
						flagCO = 0;
						flagEI = 0;
					}
					else {
						TurnoJ1(matrix, matrixConteo, respuesta);
						matrix[ia + 1] = resp;
						matrixConteo[ia + 1] = resp2;
						pasarJ2 = true;
						flagCO = 0;
						flagEI = 0;
					}
				}
				ganador = GanaJ1(matrix);
				DesBloq(matrix);
				system("clear");
				imprimirMatrix(matrix);
				MConteo(matrix, matrixConteo);
			}
			if (ganador == 0) {
				while (!pasarJ1) {
					printf("Jugador 2: Digite la letra correspondiente a su casilla (o digite 5 para ver la ayuda) \n");
					scanf(" %c", &respuesta);
					int ia = respuesta;
					//scanf not assembly related problem 
					if (ia >= 48 && ia <= 57) {
						flagEI = 1;
					}
					ia = ia - 65;
					//assembly bug
					resp = matrix[ia + 1];
					resp2 = matrixConteo[ia + 1];
					if (ia >= 0) {
						flagEI = EI(ia);
						flagCO = CO(ia, matrix);
					}
					if (flagEI == 1 && respuesta != '5') {
						printf("Entrada Invalida \n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (flagCO == 1) {
						printf("Casilla Ocupada\n");
						flagCO = 0;
						flagEI = 0;
					}
					else if (respuesta == '5') {
						imprimirMatrixE();
						flagCO = 0;
						flagEI = 0;
					}
					else {
						TurnoJ2(matrix, matrixConteo, respuesta);
						matrix[ia + 1] = resp;
						matrixConteo[ia + 1] = resp2;
						pasarJ1 = true;
						flagCO = 0;
						flagEI = 0;
					}
				}
				ganador = GanaJ2(matrix);
				system("clear");
				imprimirMatrix(matrix);
				MConteo(matrix, matrixConteo);
			}
		}
		printf("Gana jugador ");
		printf("%d", ganador);
		printf("\n");
		printf("Desea continuar? (N para no, otro digito para si)\n");
		scanf(" %c", &respuesta2);
	}
	}
    return 0;
}